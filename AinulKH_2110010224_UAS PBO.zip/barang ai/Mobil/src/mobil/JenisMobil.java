
package mobil;

public class JenisMobil {
    String nama;
    int tahunKeluar;
    String warna;
    
    
    public void mobilLangka(){
        this.nama = "Lamborgini";
    }

    
    
}
