
package mobil;


public class Mobil {

    
    public static void main(String[] args) {
        JenisMobil mobilMatic = new JenisMobil();
        
        mobilMatic.nama = "Daihatsu Ayla";
        mobilMatic.tahunKeluar = 2015;
        mobilMatic.warna = "Merah";
        
        JenisMobil mobilKopling = new JenisMobil();
        
        mobilKopling.nama = "Kijang inova";
        mobilKopling.tahunKeluar = 2009;
        mobilKopling.warna = "Hitam";
        
        System.out.println(mobilMatic.nama);
        System.out.println(mobilKopling.tahunKeluar);
        
        System.out.println(mobilKopling.warna);
        
        
    }
    
}
